module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "08500850",
    DATABASE: "telegram_app",
    DIALECT: "mysql"
}